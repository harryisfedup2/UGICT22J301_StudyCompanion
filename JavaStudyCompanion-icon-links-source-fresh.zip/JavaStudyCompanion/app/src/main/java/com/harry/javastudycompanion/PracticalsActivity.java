package com.harry.javastudycompanion;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class PracticalsActivity extends AppCompatActivity {

    private final int bg = 0xFF0B1020;
    private final int surface = 0xFF151D32;
    private final int surface2 = 0xFF1C2942;
    private final int accent = 0xFF7C9CFF;
    private final int text = 0xFFF3F6FF;
    private final int muted = 0xFFB6C2D9;
    private final int green = 0xFF8BE0B0;
    private OnBackPressedCallback detailBackCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat systemBars = WindowCompat.getInsetsController(
                getWindow(), getWindow().getDecorView());
        systemBars.setAppearanceLightStatusBars(false);
        systemBars.setAppearanceLightNavigationBars(false);

        detailBackCallback = new OnBackPressedCallback(false) {
            @Override
            public void handleOnBackPressed() {
                showList();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, detailBackCallback);
        showList();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private void applySystemBarInsets(View view, int left, int top, int right, int bottom) {
        ViewCompat.setOnApplyWindowInsetsListener(view, (target, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            target.setPadding(left + bars.left, top + bars.top,
                    right + bars.right, bottom + bars.bottom);
            return windowInsets;
        });
    }

    private TextView label(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setLineSpacing(dp(3), 1f);
        return view;
    }

    private void showList() {
        if (detailBackCallback != null) detailBackCallback.setEnabled(false);

        LinearLayout root = column();
        root.setBackgroundColor(bg);
        applySystemBarInsets(root, dp(20), dp(22), dp(20), dp(20));

        TextView eyebrow = label("UGICT22J301  •  JAVA", 12, accent, true);
        root.addView(eyebrow);

        TextView heading = label("Practical Laboratory", 27, text, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(8);
        root.addView(heading, hp);

        TextView subtitle = label("Choose a practical to explore its explanation, Java code and output.", 14, muted, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(7);
        sp.bottomMargin = dp(18);
        root.addView(subtitle, sp);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        LinearLayout items = column();

        for (int i = 0; i < PracticalData.TITLES.length; i++) {
            final int index = i;
            LinearLayout card = column();
            card.setPadding(dp(16), dp(14), dp(16), dp(14));
            card.setBackground(rounded(surface, 16, 0xFF263653));

            TextView number = label(String.format(java.util.Locale.getDefault(), "PRACTICAL %02d", i + 1), 11, accent, true);
            TextView title = label(PracticalData.TITLES[i].replaceFirst("^\\d+\\.\\s*", ""), 16, text, true);
            TextView desc = label(PracticalData.EXPLANATIONS[i], 13, muted, false);

            card.addView(number);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
            tp.topMargin = dp(5);
            card.addView(title, tp);
            LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(-1, -2);
            dpv.topMargin = dp(5);
            card.addView(desc, dpv);
            card.setOnClickListener(v -> showDetail(index));

            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = dp(11);
            items.addView(card, cp);
        }
        scroll.addView(items);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private void showDetail(int index) {
        if (index < 0 || index >= PracticalData.TITLES.length
                || index >= PracticalData.EXPLANATIONS.length
                || index >= PracticalData.CODES.length
                || index >= PracticalData.OUTPUTS.length) {
            Toast.makeText(this, "This practical is unavailable", Toast.LENGTH_SHORT).show();
            showList();
            return;
        }

        detailBackCallback.setEnabled(true);

        LinearLayout root = column();
        root.setBackgroundColor(bg);
        applySystemBarInsets(root, 0, 0, 0, 0);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(20), dp(12), dp(20), dp(12));

        TextView back = label("‹  Back", 14, text, true);
        back.setTextColor(text);
        back.setGravity(Gravity.CENTER);
        back.setPadding(dp(14), dp(9), dp(14), dp(9));
        back.setMinHeight(dp(44));
        back.setBackground(rounded(surface2, 22, 0));
        back.setContentDescription("Back to practical list");
        back.setFocusable(true);
        back.setOnClickListener(v -> showList());
        top.addView(back);

        TextView topTitle = label(String.format(java.util.Locale.ROOT,
                "PRACTICAL %02d  /  %02d", index + 1, PracticalData.TITLES.length), 11, accent, true);
        topTitle.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams topTitleParams = new LinearLayout.LayoutParams(0, -2, 1f);
        top.addView(topTitle, topTitleParams);
        root.addView(top);

        ScrollView pageScroll = new ScrollView(this);
        pageScroll.setFillViewport(false);
        pageScroll.setVerticalScrollBarEnabled(true);
        pageScroll.setScrollbarFadingEnabled(true);
        LinearLayout content = column();
        content.setPadding(dp(20), dp(10), dp(20), dp(30));

        TextView eyebrow = label("JAVA PRACTICAL  •  " + String.format(java.util.Locale.ROOT, "%02d", index + 1),
                11, accent, true);
        content.addView(eyebrow);

        TextView title = label(PracticalData.TITLES[index].replaceFirst("^\\d+\\.\\s*", ""), 25, text, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = dp(7);
        content.addView(title, titleParams);

        addSectionLabel(content, "OVERVIEW");
        addCardText(content, PracticalData.EXPLANATIONS[index], 15, muted);

        addSectionLabel(content, "JAVA PROGRAM");
        LinearLayout codeCard = column();
        codeCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        codeCard.setBackground(rounded(0xFF101827, 14, 0xFF30415F));

        LinearLayout codeHeader = new LinearLayout(this);
        codeHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView codeTag = label("JAVA  •  SOURCE CODE", 11, green, true);
        codeHeader.addView(codeTag, new LinearLayout.LayoutParams(0, -2, 1f));

        Button copy = new Button(this);
        copy.setText("Copy code");
        copy.setTextSize(12);
        copy.setAllCaps(false);
        copy.setTextColor(0xFF0B1020);
        copy.setPadding(dp(12), 0, dp(12), 0);
        copy.setMinHeight(dp(40));
        copy.setBackground(rounded(accent, 18, 0));
        copy.setContentDescription("Copy Java source code");
        copy.setOnClickListener(v -> copyCode(PracticalData.CODES[index]));
        codeHeader.addView(copy);
        codeCard.addView(codeHeader);

        TextView scrollHint = label("Scroll vertically and horizontally to view the full program.",
                11, muted, false);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(5);
        codeCard.addView(scrollHint, hintParams);

        ScrollView vertical = new ScrollView(this);
        vertical.setFillViewport(false);
        vertical.setNestedScrollingEnabled(false);
        vertical.setVerticalScrollBarEnabled(true);
        vertical.setScrollbarFadingEnabled(false);
        vertical.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        horizontal.setFillViewport(false);
        horizontal.setNestedScrollingEnabled(false);
        horizontal.setHorizontalScrollBarEnabled(true);
        horizontal.setScrollbarFadingEnabled(false);
        horizontal.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        TextView code = label(PracticalData.CODES[index], 13, 0xFFE4ECFF, false);
        code.setTypeface(Typeface.MONOSPACE);
        // Selection gestures compete with two-axis scrolling on long source listings.
        code.setTextIsSelectable(false);
        code.setHorizontallyScrolling(true);
        code.setLineSpacing(dp(2), 1f);
        code.setPadding(dp(14), dp(14), dp(18), dp(14));
        horizontal.addView(code, new HorizontalScrollView.LayoutParams(-2, -2));
        vertical.addView(horizontal, new ScrollView.LayoutParams(-1, -2));
        protectCodeScrollFromPageScroll(code, vertical);
        vertical.setBackground(rounded(0xFF0E1628, 11, 0xFF293955));
        vertical.setClipToOutline(true);
        LinearLayout.LayoutParams viewportParams = new LinearLayout.LayoutParams(-1, dp(260));
        viewportParams.topMargin = dp(12);
        codeCard.addView(vertical, viewportParams);

        LinearLayout.LayoutParams codeParams = new LinearLayout.LayoutParams(-1, -2);
        codeParams.bottomMargin = dp(4);
        content.addView(codeCard, codeParams);

        addSectionLabel(content, "EXPECTED OUTPUT");
        TextView output = label(PracticalData.OUTPUTS[index], 14, green, false);
        output.setTypeface(Typeface.MONOSPACE);
        output.setTextIsSelectable(true);
        output.setPadding(dp(16), dp(15), dp(16), dp(15));
        output.setBackground(rounded(0xFF10251F, 14, 0xFF285A45));
        content.addView(output);

        pageScroll.addView(content);
        root.addView(pageScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private void addSectionLabel(LinearLayout parent, String value) {
        TextView section = label(value, 11, accent, true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(22);
        params.bottomMargin = dp(9);
        parent.addView(section, params);
    }

    private void protectCodeScrollFromPageScroll(View touchTarget, ScrollView codeScroller) {
        touchTarget.setOnTouchListener((view, event) -> {
            int action = event.getActionMasked();
            if (action == android.view.MotionEvent.ACTION_DOWN
                    || action == android.view.MotionEvent.ACTION_MOVE) {
                codeScroller.requestDisallowInterceptTouchEvent(true);
            } else if (action == android.view.MotionEvent.ACTION_UP
                    || action == android.view.MotionEvent.ACTION_CANCEL) {
                codeScroller.requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });
    }

    private void addCardText(LinearLayout parent, String value, int size, int color) {
        TextView body = label(value, size, color, false);
        body.setPadding(dp(16), dp(15), dp(16), dp(15));
        body.setBackground(rounded(surface, 14, 0xFF263653));
        parent.addView(body);
    }

    private void copyCode(String code) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null) {
            Toast.makeText(this, "Copy is unavailable on this device", Toast.LENGTH_SHORT).show();
            return;
        }
        clipboard.setPrimaryClip(ClipData.newPlainText("Java practical code", code));
        Toast.makeText(this, "Java code copied", Toast.LENGTH_SHORT).show();
    }
}
