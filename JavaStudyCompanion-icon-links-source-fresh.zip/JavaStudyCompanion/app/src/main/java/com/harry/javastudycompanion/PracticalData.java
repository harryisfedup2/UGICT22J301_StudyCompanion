
package com.harry.javastudycompanion;

public class PracticalData {

    public static final String[] TITLES = {
            "1. Generate first n prime numbers",
            "2. Maximum of three numbers using conditional operator",
            "3. Reverse digits using while loop",
            "4. Calculate factorial of a number",
            "5. Demonstrate the this keyword and private members",
            "6. Rectangle area and perimeter using super and this",
            "7. Abstract classes and methods",
            "8. Access modifiers in Java",
            "9. Sort elements of an array",
            "10. Matrix operations using multidimensional arrays",
            "11. Constructor overloading",
            "12. Copy constructor",
            "13. Demonstrate the final keyword in field declaration",
            "14. Single, multilevel and hierarchical inheritance",
            "15. Method overriding",
            "16. Subclass constructor invoking superclass constructor",
            "17. Demonstrate final class",
            "18. Multiple try blocks and multiple catch exceptions",
            "19. Nested try statements",
            "20. Exception handling using multiple catch blocks",
            "21. User-defined exception using throw",
            "22. Package access: same and external classes",
            "23. Import and access a user-defined package",
            "24. Implementation of interfaces",
            "25. AWT program for string operations",
            "26. Create multiple threads in Java",
            "27. Implement thread using Runnable interface",
            "28. String methods: equals, reverse and change case",
            "29. Concatenate strings using StringBuffer",
            "30. Basic calculator operations"
    };

    public static final String[] EXPLANATIONS = {
            "A prime number is divisible only by 1 and itself. This program generates the first n prime numbers.",
            "The conditional operator (?:) selects the greatest of three numbers.",
            "A while loop extracts digits and reverses their order using arithmetic operations.",
            "Factorial is the product of all positive integers from 1 to a given number.",
            "The this keyword refers to the current object. Private members can be accessed inside their own class.",
            "The super keyword accesses superclass members, while this refers to the current object.",
            "An abstract class can contain abstract and concrete methods. Subclasses implement abstract methods.",
            "Access modifiers control the visibility of classes, variables and methods.",
            "An array stores multiple values. Sorting arranges its elements in ascending order.",
            "A two-dimensional array stores data in rows and columns, like a matrix.",
            "Constructor overloading means defining multiple constructors with different parameter lists.",
            "A copy constructor creates a new object by copying values from another object.",
            "The final keyword prevents a variable from being reassigned after initialization.",
            "Inheritance allows classes to acquire properties and methods from another class.",
            "Method overriding allows a subclass to provide its own implementation of an inherited method.",
            "A subclass constructor uses super() to invoke its superclass constructor.",
            "A final class cannot be extended by another class.",
            "Separate try-catch structures can handle exceptions from different operations.",
            "A nested try statement places one try block inside another try block.",
            "Multiple catch blocks handle different exception types separately.",
            "A user-defined exception is created by extending the Exception class.",
            "Package access demonstrates how classes in a package can use accessible members.",
            "The import statement allows a class to use a class from another package.",
            "An interface defines methods that an implementing class must provide.",
            "AWT provides GUI components. This example performs string operations through a window.",
            "Multiple threads allow different tasks to execute concurrently.",
            "The Runnable interface provides a way to define a task for a thread.",
            "String methods can compare, reverse and change the case of text.",
            "StringBuffer allows strings to be modified and concatenated.",
            "A calculator performs arithmetic operations such as addition, subtraction, multiplication and division."
    };

    public static final String[] CODES = {
            // 1. Prime numbers
            "class PrimeNumbers {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        int n = 5, count = 0, num = 2;\n" +
                    "        while (count < n) {\n" +
                    "            boolean prime = true;\n" +
                    "            for (int i = 2; i <= num / 2; i++) {\n" +
                    "                if (num % i == 0) { prime = false; break; }\n" +
                    "            }\n" +
                    "            if (prime) { System.out.print(num + \" \"); count++; }\n" +
                    "            num++;\n" +
                    "        }\n" +
                    "    }\n}",

            // 2. Conditional operator
            "class Maximum {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        int a = 10, b = 25, c = 15;\n" +
                    "        int max = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c);\n" +
                    "        System.out.println(\"Maximum = \" + max);\n" +
                    "    }\n}",

            // 3. Reverse digits
            "class ReverseNumber {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        int num = 1234, reverse = 0;\n" +
                    "        while (num != 0) {\n" +
                    "            int digit = num % 10;\n" +
                    "            reverse = reverse * 10 + digit;\n" +
                    "            num = num / 10;\n" +
                    "        }\n" +
                    "        System.out.println(\"Reverse = \" + reverse);\n" +
                    "    }\n}",

            // 4. Factorial
            "class Factorial {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        int n = 5;\n" +
                    "        long fact = 1;\n" +
                    "        for (int i = 1; i <= n; i++) fact *= i;\n" +
                    "        System.out.println(\"Factorial = \" + fact);\n" +
                    "    }\n}",

            // 5. this and private members
            "class Student {\n" +
                    "    private String name;\n" +
                    "    Student(String name) { this.name = name; }\n" +
                    "    void display() { System.out.println(this.name); }\n" +
                    "}\n" +
                    "class ThisDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        Student s = new Student(\"Harry\");\n" +
                    "        s.display();\n" +
                    "    }\n}",

            // 6. super and this
            "class Shape {\n" +
                    "    int length = 10, breadth = 5;\n" +
                    "}\n" +
                    "class Rectangle extends Shape {\n" +
                    "    void calculate() {\n" +
                    "        int area = super.length * super.breadth;\n" +
                    "        System.out.println(\"Area = \" + area);\n" +
                    "        System.out.println(\"Perimeter = \" +\n" +
                    "            2 * (this.length + this.breadth));\n" +
                    "    }\n" +
                    "}\n" +
                    "class RectangleDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new Rectangle().calculate();\n" +
                    "    }\n}",

            // 7. Abstract class
            "abstract class Animal {\n" +
                    "    abstract void sound();\n" +
                    "}\n" +
                    "class Dog extends Animal {\n" +
                    "    void sound() { System.out.println(\"Dog barks\"); }\n" +
                    "}\n" +
                    "class AbstractDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        Animal a = new Dog();\n" +
                    "        a.sound();\n" +
                    "    }\n}",

            // 8. Access modifiers
            "class AccessDemo {\n" +
                    "    public int a = 10;\n" +
                    "    private int b = 20;\n" +
                    "    protected int c = 30;\n" +
                    "    int d = 40;\n" +
                    "    void display() {\n" +
                    "        System.out.println(a + \" \" + b + \" \" + c + \" \" + d);\n" +
                    "    }\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new AccessDemo().display();\n" +
                    "    }\n}",

            // 9. Sort array
            "import java.util.Arrays;\n" +
                    "class SortArray {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        int[] a = {5, 2, 8, 1, 3};\n" +
                    "        Arrays.sort(a);\n" +
                    "        System.out.println(Arrays.toString(a));\n" +
                    "    }\n}",

            // 10. Matrix addition
            "class MatrixAddition {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        int[][] a = {{1, 2}, {3, 4}};\n" +
                    "        int[][] b = {{5, 6}, {7, 8}};\n" +
                    "        for (int i = 0; i < 2; i++) {\n" +
                    "            for (int j = 0; j < 2; j++) {\n" +
                    "                System.out.print((a[i][j] + b[i][j]) + \" \");\n" +
                    "            }\n" +
                    "            System.out.println();\n" +
                    "        }\n" +
                    "    }\n}",

            // 11. Constructor overloading
            "class Box {\n" +
                    "    int length, breadth;\n" +
                    "    Box() { length = 1; breadth = 1; }\n" +
                    "    Box(int l, int b) { length = l; breadth = b; }\n" +
                    "    void display() { System.out.println(length * breadth); }\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new Box().display();\n" +
                    "        new Box(5, 4).display();\n" +
                    "    }\n}",

            // 12. Copy constructor
            "class CopyStudent {\n" +
                    "    int marks;\n" +
                    "    CopyStudent(int marks) { this.marks = marks; }\n" +
                    "    CopyStudent(CopyStudent s) { this.marks = s.marks; }\n" +
                    "    public static void main(String[] args) {\n" +
                    "        CopyStudent s1 = new CopyStudent(90);\n" +
                    "        CopyStudent s2 = new CopyStudent(s1);\n" +
                    "        System.out.println(s2.marks);\n" +
                    "    }\n}",

            // 13. final field
            "class FinalDemo {\n" +
                    "    final int VALUE = 100;\n" +
                    "    public static void main(String[] args) {\n" +
                    "        FinalDemo obj = new FinalDemo();\n" +
                    "        System.out.println(obj.VALUE);\n" +
                    "    }\n}",

            // 14. Inheritance
            "class AnimalBase {\n" +
                    "    void eat() { System.out.println(\"Eating\"); }\n" +
                    "}\n" +
                    "class DogChild extends AnimalBase { }\n" +
                    "class Puppy extends DogChild { }\n" +
                    "class CatChild extends AnimalBase { }\n" +
                    "class InheritanceDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new Puppy().eat();\n" +
                    "        new CatChild().eat();\n" +
                    "    }\n}",

            // 15. Method overriding
            "class Parent {\n" +
                    "    void show() { System.out.println(\"Parent method\"); }\n" +
                    "}\n" +
                    "class Child extends Parent {\n" +
                    "    @Override\n" +
                    "    void show() { System.out.println(\"Child method\"); }\n" +
                    "}\n" +
                    "class OverrideDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new Child().show();\n" +
                    "    }\n}",

            // 16. Superclass constructor
            "class ParentClass {\n" +
                    "    ParentClass() { System.out.println(\"Parent constructor\"); }\n" +
                    "}\n" +
                    "class ChildClass extends ParentClass {\n" +
                    "    ChildClass() { super(); System.out.println(\"Child constructor\"); }\n" +
                    "}\n" +
                    "class ConstructorDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new ChildClass();\n" +
                    "    }\n}",

            // 17. Final class
            "final class Vehicle {\n" +
                    "    void show() { System.out.println(\"Final class example\"); }\n" +
                    "}\n" +
                    "class FinalClassDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new Vehicle().show();\n" +
                    "    }\n}",

            // 18. Multiple try-catch structures
            "class MultipleTry {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        try { int a = 10 / 0; }\n" +
                    "        catch (ArithmeticException e) { System.out.println(\"Division error\"); }\n" +
                    "        try { int[] a = {1, 2}; System.out.println(a[5]); }\n" +
                    "        catch (ArrayIndexOutOfBoundsException e) { System.out.println(\"Array error\"); }\n" +
                    "    }\n}",

            // 19. Nested try
            "class NestedTry {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        try {\n" +
                    "            try { int a = 10 / 0; }\n" +
                    "            catch (ArithmeticException e) { System.out.println(\"Inner catch\"); }\n" +
                    "            int[] x = {1, 2};\n" +
                    "            System.out.println(x[5]);\n" +
                    "        } catch (ArrayIndexOutOfBoundsException e) {\n" +
                    "            System.out.println(\"Outer catch\");\n" +
                    "        }\n" +
                    "    }\n}",

            // 20. Multiple catch blocks
            "class MultipleCatch {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        try {\n" +
                    "            int a = Integer.parseInt(\"abc\");\n" +
                    "            System.out.println(a);\n" +
                    "        } catch (NumberFormatException e) {\n" +
                    "            System.out.println(\"Invalid number\");\n" +
                    "        } catch (Exception e) {\n" +
                    "            System.out.println(\"Other error\");\n" +
                    "        }\n" +
                    "    }\n}",

            // 21. User-defined exception
            "class AgeException extends Exception {\n" +
                    "    AgeException(String message) { super(message); }\n" +
                    "}\n" +
                    "class CustomExceptionDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        int age = 15;\n" +
                    "        try {\n" +
                    "            if (age < 18) throw new AgeException(\"Not eligible\");\n" +
                    "            System.out.println(\"Eligible\");\n" +
                    "        } catch (AgeException e) {\n" +
                    "            System.out.println(e.getMessage());\n" +
                    "        }\n" +
                    "    }\n}",

            // 22. Package access
            "package mypackage;\n" +
                    "class PackageDemo {\n" +
                    "    void show() { System.out.println(\"Package member access\"); }\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new PackageDemo().show();\n" +
                    "    }\n" +
                    "}",

            // 23. Import user-defined package
            "package mypackage;\n" +
                    "public class Message {\n" +
                    "    public void display() { System.out.println(\"Hello from mypackage\"); }\n" +
                    "}\n" +
                    "// In another file, outside the package:\n" +
                    "import mypackage.Message;\n" +
                    "class UseMessage {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new Message().display();\n" +
                    "    }\n" +
                    "}",

            // 24. Interface
            "interface Printable {\n" +
                    "    void print();\n" +
                    "}\n" +
                    "class Document implements Printable {\n" +
                    "    public void print() { System.out.println(\"Printing document\"); }\n" +
                    "}\n" +
                    "class InterfaceDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new Document().print();\n" +
                    "    }\n}",

            // 25. AWT string operations
            "import java.awt.*;\n" +
                    "import java.awt.event.*;\n" +
                    "class StringAWT extends Frame implements ActionListener {\n" +
                    "    TextField input = new TextField(20);\n" +
                    "    Label result = new Label(\"Result appears here\");\n" +
                    "    Button button = new Button(\"Convert to Uppercase\");\n" +
                    "    StringAWT() {\n" +
                    "        setLayout(new FlowLayout());\n" +
                    "        add(input); add(button); add(result);\n" +
                    "        button.addActionListener(this);\n" +
                    "        setSize(350, 150); setVisible(true);\n" +
                    "        addWindowListener(new WindowAdapter() {\n" +
                    "            public void windowClosing(WindowEvent e) { dispose(); }\n" +
                    "        });\n" +
                    "    }\n" +
                    "    public void actionPerformed(ActionEvent e) {\n" +
                    "        result.setText(input.getText().toUpperCase());\n" +
                    "    }\n" +
                    "    public static void main(String[] args) { new StringAWT(); }\n}",

            // 26. Multiple threads
            "class MyThread extends Thread {\n" +
                    "    String message;\n" +
                    "    MyThread(String message) { this.message = message; }\n" +
                    "    public void run() {\n" +
                    "        for (int i = 1; i <= 3; i++) System.out.println(message + \" \" + i);\n" +
                    "    }\n" +
                    "}\n" +
                    "class ThreadDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        new MyThread(\"Thread A\").start();\n" +
                    "        new MyThread(\"Thread B\").start();\n" +
                    "    }\n}",

            // 27. Runnable
            "class MyTask implements Runnable {\n" +
                    "    public void run() {\n" +
                    "        System.out.println(\"Runnable thread is running\");\n" +
                    "    }\n" +
                    "}\n" +
                    "class RunnableDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        Thread t = new Thread(new MyTask());\n" +
                    "        t.start();\n" +
                    "    }\n}",

            // 28. String methods
            "class StringMethods {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        String a = \"Java\", b = \"Java\";\n" +
                    "        System.out.println(\"Equal: \" + a.equals(b));\n" +
                    "        System.out.println(\"Reverse: \" + new StringBuilder(a).reverse());\n" +
                    "        System.out.println(\"Uppercase: \" + a.toUpperCase());\n" +
                    "        System.out.println(\"Lowercase: \" + a.toLowerCase());\n" +
                    "    }\n}",

            // 29. StringBuffer
            "class BufferDemo {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        StringBuffer sb = new StringBuffer(\"Java\");\n" +
                    "        sb.append(\" Study Companion\");\n" +
                    "        System.out.println(sb);\n" +
                    "    }\n}",

            // 30. Calculator
            "class Calculator {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        double a = 20, b = 5;\n" +
                    "        System.out.println(\"Addition = \" + (a + b));\n" +
                    "        System.out.println(\"Subtraction = \" + (a - b));\n" +
                    "        System.out.println(\"Multiplication = \" + (a * b));\n" +
                    "        if (b != 0) System.out.println(\"Division = \" + (a / b));\n" +
                    "    }\n}"
    };

    public static final String[] OUTPUTS = {
            "2 3 5 7 11",
            "Maximum = 25",
            "Reverse = 4321",
            "Factorial = 120",
            "Harry",
            "Area = 50\nPerimeter = 30",
            "Dog barks",
            "10 20 30 40",
            "[1, 2, 3, 5, 8]",
            "6 8\n10 12",
            "1\n20",
            "90",
            "100",
            "Eating\nEating",
            "Child method",
            "Parent constructor\nChild constructor",
            "Final class example",
            "Division error\nArray error",
            "Inner catch\nOuter catch",
            "Invalid number",
            "Not eligible",
            "Package member access",
            "Hello from mypackage",
            "Printing document",
            "Displays the entered text in uppercase in an AWT window",
            "Thread A and Thread B messages (order may vary)",
            "Runnable thread is running",
            "Equal: true\nReverse: avaJ\nUppercase: JAVA\nLowercase: java",
            "Java Study Companion",
            "Addition = 25.0\nSubtraction = 15.0\nMultiplication = 100.0\nDivision = 4.0"
    };

    public static String validateData() {

        StringBuilder report = new StringBuilder();

        report.append("Total practicals: ")
                .append(TITLES.length).append("\n");

        if (EXPLANATIONS.length != TITLES.length ||
                CODES.length != TITLES.length ||
                OUTPUTS.length != TITLES.length) {

            report.append("ERROR: Array sizes do not match!\n");
            return report.toString();
        } else {
            report.append("All four arrays have matching sizes.\n");
        }

        for (int i = 0; i < TITLES.length; i++) {

            if (TITLES[i] == null || TITLES[i].trim().isEmpty())
                report.append("Missing title: ").append(i + 1).append("\n");

            if (EXPLANATIONS[i] == null || EXPLANATIONS[i].trim().isEmpty())
                report.append("Missing explanation: ").append(i + 1).append("\n");

            if (CODES[i] == null || CODES[i].trim().isEmpty())
                report.append("Missing code: ").append(i + 1).append("\n");

            if (OUTPUTS[i] == null || OUTPUTS[i].trim().isEmpty())
                report.append("Missing output: ").append(i + 1).append("\n");
        }

        if (report.toString().endsWith("matching sizes.\n")) {
            report.append("Validation completed.");
        }

        return report.toString();
    }

    public static int getCount() {
        return TITLES.length;
    }
}
