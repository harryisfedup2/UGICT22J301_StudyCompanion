package com.harry.javastudycompanion;

import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class TheoryActivity extends AppCompatActivity {
    public static final String EXTRA_UNIT = "theory_unit";
    private static final int BACKGROUND = 0xFF0B1020;
    private static final int TEXT = 0xFFF3F6FF;
    private static final int ACCENT = 0xFF7C9CFF;

    private static final String[] TITLES = {
            "", "Unit 1 · Java Fundamentals", "Unit 2 · OOP Concepts",
            "Unit 3 · Interfaces, Exceptions & Threads", "Unit 4 · Strings, GUI & JDBC"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int unit = getIntent().getIntExtra(EXTRA_UNIT, 0);
        if (unit < 1 || unit > 4) {
            finish();
            return;
        }

        WindowCompat.enableEdgeToEdge(getWindow());
        WindowInsetsControllerCompat bars = WindowCompat.getInsetsController(
                getWindow(), getWindow().getDecorView());
        bars.setAppearanceLightStatusBars(false);
        bars.setAppearanceLightNavigationBars(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BACKGROUND);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, windowInsets) -> {
            Insets systemBars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return windowInsets;
        });

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(9), dp(18), dp(9));
        header.setBackgroundColor(BACKGROUND);

        TextView back = new TextView(this);
        back.setText("‹  Back");
        back.setTextColor(TEXT);
        back.setTextSize(14);
        back.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        back.setGravity(Gravity.CENTER);
        back.setPadding(dp(13), dp(9), dp(13), dp(9));
        back.setMinHeight(dp(44));
        back.setBackground(rounded(0xFF1C2942, 22));
        back.setContentDescription("Back to course home");
        back.setOnClickListener(v -> finish());
        header.addView(back);

        TextView title = new TextView(this);
        title.setText(TITLES[unit]);
        title.setTextColor(ACCENT);
        title.setTextSize(13);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleParams.leftMargin = dp(12);
        header.addView(title, titleParams);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        WebView content = new WebView(this);
        content.setBackgroundColor(BACKGROUND);
        content.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        WebSettings settings = content.getSettings();
        settings.setJavaScriptEnabled(false);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        content.loadUrl("file:///android_asset/theory/unit" + unit + ".html");
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radiusDp));
        return shape;
    }
}
