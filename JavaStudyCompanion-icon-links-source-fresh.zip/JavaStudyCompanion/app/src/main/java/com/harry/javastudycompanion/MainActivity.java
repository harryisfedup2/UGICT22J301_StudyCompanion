package com.harry.javastudycompanion;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.enableEdgeToEdge(getWindow());
        setContentView(R.layout.activity_main);
        findViewById(R.id.btnUnit1).setOnClickListener(v -> openTheory(1));
        findViewById(R.id.btnUnit2).setOnClickListener(v -> openTheory(2));
        findViewById(R.id.btnUnit3).setOnClickListener(v -> openTheory(3));
        findViewById(R.id.btnUnit4).setOnClickListener(v -> openTheory(4));
        findViewById(R.id.btnPracticals).setOnClickListener(v -> openPracticals());
        styleContactLink(R.id.aboutEmail);
        styleContactLink(R.id.aboutInstagram);
        styleContactLink(R.id.aboutGithub);
        findViewById(R.id.aboutEmail).setOnClickListener(v -> openGmail());
        findViewById(R.id.aboutInstagram).setOnClickListener(v -> openExternalLink(
                "https://www.instagram.com/harryisfedup/"));
        findViewById(R.id.aboutGithub).setOnClickListener(v -> openExternalLink(
                "https://github.com/harryisfedup2"));
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    private void openPracticals() {
        Intent intent = new Intent(MainActivity.this, PracticalsActivity.class);
        startActivity(intent);
    }

    private void openTheory(int unit) {
        Intent intent = new Intent(MainActivity.this, TheoryActivity.class);
        intent.putExtra(TheoryActivity.EXTRA_UNIT, unit);
        startActivity(intent);
    }

    private void openExternalLink(String uri) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "No app is available to open this link", Toast.LENGTH_SHORT).show();
        }
    }

    private void openGmail() {
        Uri recipient = Uri.parse("mailto:harryisfedup2@gmail.com");
        Intent gmail = new Intent(Intent.ACTION_SENDTO, recipient);
        gmail.setPackage("com.google.android.gm");
        try {
            startActivity(gmail);
        } catch (ActivityNotFoundException notInstalled) {
            openExternalLink("https://mail.google.com/mail/?view=cm&to=harryisfedup2%40gmail.com");
        }
    }

    private void styleContactLink(int viewId) {
        TextView link = findViewById(viewId);
        link.setPaintFlags(link.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
    }

}
